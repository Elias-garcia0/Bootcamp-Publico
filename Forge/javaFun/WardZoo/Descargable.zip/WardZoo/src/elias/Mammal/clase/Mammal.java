package elias.Mammal.clase;

public class Mammal {
private int energy = 100;


//METODO
public int displayEnergy() {
	System.out.println(energy);
	return energy;
}

//GETTERS AND SETTERS
public int getEnergy() {
	return energy;
}


public void setEnergy(int energy) {
	this.energy = energy;
}


}
