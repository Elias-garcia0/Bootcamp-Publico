/**
 * 
 */
/**
 * @author pc
 *
 */
module MaestroDeObjetos {
}