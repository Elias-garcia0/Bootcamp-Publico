package elias.Ninja.clase;

import elias.Human.clase.Human;

public class Ninja extends Human {

	//CONSTRUCTOR
	public Ninja(String name) {
		super(name);
	}

}
