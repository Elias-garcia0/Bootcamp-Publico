package elias.Wizard.clase;

import elias.Human.clase.Human;

public class Wizard extends Human {

	//CONSTRUCTOR
	public Wizard(String name) {
		super(name);
	}

}
