package elias.Samurai.clase;

import elias.Human.clase.Human;

public class Samurai extends Human {

	
	//CONSTRUCTOR
	public Samurai(String name) {
		super(name);
	}

}
