public class Pitagoras {
    public static void main(String[] args) {
        Teorema calculador = new Teorema();

        double resultado = calculador.calcularHipotenusa(6, 5);
        System.out.println("El resultado es: " + resultado);
    }
}
