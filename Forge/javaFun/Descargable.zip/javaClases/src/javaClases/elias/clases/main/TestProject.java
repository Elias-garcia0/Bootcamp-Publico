package javaClases.elias.clases.main;
import javaClases.elias.clases.clases.*;

public class TestProject {

	public static void main(String[] args) {
		
		 Project clase1 = new Project("Nombre 1", "Descripcion 1");
		 Project clase2 = new Project("Nombre 2", "Descripcion 2");
		 Project clase3 = new Project("Nombre 3", "Descripcion 3");
		
		 clase1.elevatorPitch();
		 clase3.elevatorPitch();
		 
		
	}

	


		
		
		
	}

