package com.elias.listadeestudiantes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListadeestudiantesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ListadeestudiantesApplication.class, args);
	}

}
