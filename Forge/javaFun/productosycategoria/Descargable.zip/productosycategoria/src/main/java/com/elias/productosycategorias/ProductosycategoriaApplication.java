package com.elias.productosycategorias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductosycategoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductosycategoriaApplication.class, args);
	}

}
