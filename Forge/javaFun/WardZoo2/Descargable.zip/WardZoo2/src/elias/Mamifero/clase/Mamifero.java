package elias.Mamifero.clase;

public class Mamifero {
	int energy = 300;

	
	//GETTERS AND SETTERS
	public int getEnergy() {
		return energy;
	}

	public void setEnergy(int energy) {
		this.energy = energy;
	}

	
}
