package com.elias.enrrutamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrrutamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
