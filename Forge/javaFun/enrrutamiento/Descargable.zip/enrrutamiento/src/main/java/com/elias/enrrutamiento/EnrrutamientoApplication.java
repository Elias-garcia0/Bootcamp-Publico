package com.elias.enrrutamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnrrutamientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnrrutamientoApplication.class, args);
	}

}
