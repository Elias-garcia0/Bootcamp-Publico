public class Llamado {
    public static void main(String[] args) {
        FizzBuzz fb = new FizzBuzz();
        System.out.println(fb.fizzBuzz(6));
        System.out.println(fb.fizzBuzz(15));
         System.out.println(fb.fizzBuzz(10));
    }
}
