package com.elias.contador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
