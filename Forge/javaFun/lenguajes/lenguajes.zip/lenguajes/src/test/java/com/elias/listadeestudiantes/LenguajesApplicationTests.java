package com.elias.listadeestudiantes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LenguajesApplicationTests {

	@Test
	void contextLoads() {
	}

}
